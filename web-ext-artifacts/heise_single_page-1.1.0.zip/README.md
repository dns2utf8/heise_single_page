# heise_single_page

**Displays news articles on heise.de and m.heise.de on a single page**

Zeigt Heise Artikel auf einer Seite an.
Das Addon entfernt keine Werbung dafür gibt es z.B. uBlock Origin und Privacy Badger.
