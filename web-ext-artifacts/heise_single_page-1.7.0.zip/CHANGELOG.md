# Changelog

# 1.7.0

- Add techstage.de domain

# 1.6.0

- Mark Affiliate Links

# 1.5.0

- Increase last resort timer
- Adapt to the new Firefox 79 manifest format

# 1.4.1

- Fix remove tracking notice consent box

# 1.4.0

- Show the Heise logo infront of links to other articles

# 1.3.2

- Delayed Tracker notice optimized

# 1.3.1

- Switch to BSD-4 license
- Add more events

# 1.3.0

- Add a config option to remove the broken tracking options modal dialog, synchronized if user uses firefox sync
- Add a Changelog
- Add new permission "storage" for storing the settings

# 1.2.0

- Add incognito mark until "split" is supported by firefox
- Reduce noise of pure click-bait articles

# 1.1.1

- Include inline Plus Links

# 1.1.0

- Open Forum Thread automaticaly
- Implement Heise+ highlight

# 1.0.3

- run_at document_end

# 1.0.2

- Use bubbeling for the clicking

# 1.0.1

- Fix Firefox Desktop

# 1.0.0

- Initial release
