# heise_single_page

**Displays news articles on heise.de and m.heise.de on a single page**

