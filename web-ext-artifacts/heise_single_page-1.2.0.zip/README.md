# heise_single_page

**Displays news articles on heise.de and m.heise.de on a single page**

Zeigt Heise Artikel auf einer Seite an.
Das Addon entfernt keine Werbung dafür gibt es z.B. uBlock Origin und Privacy Badger.

## Features

* Artikel werden automatisch auf einer Seite angezeigt (ausgenommen Heise-Auto)
* Heise+ Artikel werden optisch hervorgehoben
* Heise-Angebote werden optisch leiser
